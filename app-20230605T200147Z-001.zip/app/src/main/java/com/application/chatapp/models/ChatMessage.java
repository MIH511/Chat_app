package com.application.chatapp.models;

import java.util.Date;

public class ChatMessage {

    public String senderId, receiverId, message, dateTime;
    public Date dateObject;
    public String conversationId, conversationName, ConversationImage;
}
