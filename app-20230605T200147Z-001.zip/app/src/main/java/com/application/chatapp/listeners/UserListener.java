package com.application.chatapp.listeners;

import com.application.chatapp.models.User;

public interface UserListener {

    public void setListener(User user);
}
