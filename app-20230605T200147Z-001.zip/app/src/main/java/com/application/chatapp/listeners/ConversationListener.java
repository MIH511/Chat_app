package com.application.chatapp.listeners;

import com.application.chatapp.models.User;

public interface ConversationListener {

    void onConversationClicked(User user);
}
